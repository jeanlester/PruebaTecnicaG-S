﻿using RESTAPIJeanlester.DataAccess.Dapper;
using RESTAPIJeanlester.Doman;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RESTAPIJeanlester.Services
{
    public class ClienteService : IClienteService
    {
        protected readonly IClienteRepository _clienteRepository;
        public ClienteService(IClienteRepository clienteRepository) 
        {
            _clienteRepository = clienteRepository;
        }
        public void ActualizarCliente(Cliente cliente)
        {
            _clienteRepository.ActualizarCliente(cliente);
        }

        public void AddCliente(Cliente cliente)
        {
            _clienteRepository.AddCliente(cliente);
        }

        public void EliminarCliente(int Id)
        {
            _clienteRepository.EliminarCliente(Id);
        }

        public Task<Cliente> ObtenerClientePorId(int Id)
        {
            return _clienteRepository.ObtenerClientePorIdAsync(Id);
        }

        public Task<Cliente> ObtenerClientePorTelefono(string Telefono)
        {
            return _clienteRepository.ObtenerClientePorTelefonoAsync(Telefono);
        }

        public Task<IEnumerable<Cliente>> ObtenerTodosClientes()
        {
            return _clienteRepository.ObtenerTodosClientesAsync();
        }
    }
}
