﻿using RESTAPIJeanlester.Doman;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RESTAPIJeanlester.Services
{
    public interface IClienteService
    {
        Task<IEnumerable<Cliente>> ObtenerTodosClientes();
        Task<Cliente> ObtenerClientePorId(Int32 Id);
        Task<Cliente> ObtenerClientePorTelefono(String Telefono);
        void AddCliente(Cliente cliente);
        void ActualizarCliente(Cliente cliente);
        void EliminarCliente(Int32 Id);

    }
}
