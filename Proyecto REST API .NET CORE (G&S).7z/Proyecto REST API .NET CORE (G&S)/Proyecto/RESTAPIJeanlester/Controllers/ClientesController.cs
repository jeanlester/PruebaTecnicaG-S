﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RESTAPIJeanlester.Doman;
using RESTAPIJeanlester.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RESTAPIJeanlester.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class ClientesController : ControllerBase
    {
        protected readonly IClienteService _clienteService;
        public ClientesController(IClienteService clienteService)
        {
            _clienteService = clienteService;
        }

        [Route("[action]")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ObtenerTodosClientes() 
        {
            var clientes = await _clienteService.ObtenerTodosClientes();
            return Ok(clientes);
        }

        [Route("[action]")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ObtenerClientePorId(Int32 Id)
        {
            var clientes = await _clienteService.ObtenerClientePorId(Id);
            return Ok(clientes);
        }

        [Route("[action]")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<IActionResult> ObtenerClientePorTelefono(String Telefono)
        {
            var clientes = await _clienteService.ObtenerClientePorTelefono(Telefono);
            return Ok(clientes);
        }

        [Route("[action]")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult InsertarCliente([FromBody] Cliente cliente)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            _clienteService.AddCliente(cliente);
            return CreatedAtAction(nameof(ObtenerClientePorId), new { Id = cliente.Id }, cliente);
        }

        [Route("[action]")]
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult ActualizarCliente([FromBody] Cliente cliente)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            _clienteService.ActualizarCliente(cliente);
            return Ok();
        }

        [Route("[action]")]
        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IActionResult EliminarCliente(Int32 Id)
        {
            _clienteService.EliminarCliente(Id);
            return Ok();
        }

    }
}
