﻿using RESTAPIJeanlester.Doman;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RESTAPIJeanlester.DataAccess.Dapper
{
    public interface IClienteRepository
    {
        Task<IEnumerable<Cliente>> ObtenerTodosClientesAsync();
        Task<Cliente> ObtenerClientePorIdAsync(Int32 Id);
        Task<Cliente> ObtenerClientePorTelefonoAsync(String Telefono);
        void AddCliente(Cliente cliente);
        void ActualizarCliente(Cliente cliente);
        void EliminarCliente(Int32 Id);


    }
}
