﻿using Dapper;
using Microsoft.Extensions.Configuration;
using RESTAPIJeanlester.Doman;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace RESTAPIJeanlester.DataAccess.Dapper
{
    public class ClienteRepository : IClienteRepository
    {
        protected readonly IConfiguration _config;
        public ClienteRepository(IConfiguration config)
        {
            _config = config;
        }

        public IDbConnection Connection 
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString("ClienteDbConnection"));
            }
        }

        public void ActualizarCliente(Cliente cliente)
        {
            try
            {
                var parametros = new DynamicParameters();
                parametros.Add("@Id", cliente.Id);
                parametros.Add("@Nombres", cliente.Nombres);
                parametros.Add("@Apellidos", cliente.Apellidos);
                parametros.Add("@Direccion", cliente.Direccion);
                parametros.Add("@Telefono", cliente.Telefono);

                using (IDbConnection dbConnection = Connection) 
                {
                    dbConnection.Open();
                    dbConnection.Execute("sp_GuardarActualizar_Cliente", parametros, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AddCliente(Cliente cliente)
        {
            try
            {
                var parametros = new DynamicParameters();
                parametros.Add("@Id", cliente.Id);
                parametros.Add("@Nombres", cliente.Nombres);
                parametros.Add("@Apellidos", cliente.Apellidos);
                parametros.Add("@Direccion", cliente.Direccion);
                parametros.Add("@Telefono", cliente.Telefono);

                using (IDbConnection dbConnection = Connection)
                {
                    dbConnection.Open();
                    dbConnection.Execute("sp_GuardarActualizar_Cliente", parametros, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminarCliente(int Id)
        {
            try
            {
                var parametros = new DynamicParameters();
                parametros.Add("@Id", Id);

                using (IDbConnection dbConnection = Connection)
                {
                    dbConnection.Open();
                    dbConnection.Execute("sp_EliminarCliente_Id", parametros, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Cliente> ObtenerClientePorIdAsync(int Id)
        {
            try
            {

                var parametros = new DynamicParameters();
                parametros.Add("@Id", Id);

                using (IDbConnection dbConnection = Connection)
                {
                    dbConnection.Open();
                    return await dbConnection.QueryFirstOrDefaultAsync<Cliente>("sp_ObtenerCliente_Id", parametros, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Cliente> ObtenerClientePorTelefonoAsync(string Telefono)
        {
            try
            {
                var parametros = new DynamicParameters();
                parametros.Add("@Telefono", Telefono);

                using (IDbConnection dbConnection = Connection)
                {
                    dbConnection.Open();
                    return await dbConnection.QueryFirstOrDefaultAsync<Cliente>("sp_ObtenerCliente_Telefono", parametros, commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IEnumerable<Cliente>> ObtenerTodosClientesAsync()
        {
            try
            {
                using (IDbConnection dbConnection = Connection)
                {
                    dbConnection.Open();
                    return await dbConnection.QueryAsync<Cliente>("sp_ObtenerClientes", commandType: CommandType.StoredProcedure);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
